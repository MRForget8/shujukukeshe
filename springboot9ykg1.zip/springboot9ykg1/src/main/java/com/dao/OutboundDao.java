package com.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.entity.OutboundEntity;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface OutboundDao extends BaseMapper<OutboundEntity> {
	
}
