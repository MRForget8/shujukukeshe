package com.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.entity.WarehousingEntity;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface WarehousingDao extends BaseMapper<WarehousingEntity> {
	
}
